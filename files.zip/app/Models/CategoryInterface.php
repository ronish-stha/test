<?php
namespace App\Models;

use Franzose\ClosureTable\Contracts\EntityInterface;

interface CategoryInterface extends EntityInterface
{
}
