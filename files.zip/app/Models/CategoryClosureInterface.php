<?php
namespace App\Models;

use Franzose\ClosureTable\Contracts\ClosureTableInterface;

interface CategoryClosureInterface extends ClosureTableInterface
{
}
