<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
<input type="text" placeholder="Search">
</body>
</html>
