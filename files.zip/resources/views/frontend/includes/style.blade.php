<link rel="stylesheet" href="{{URL::asset('frontend/css/bootstrap.min.css')}}">
<link rel="stylesheet" href="{{URL::asset('frontend/css/magnific-popup.css')}}">
<link rel="stylesheet" href="{{URL::asset('frontend/css/animate.css')}}">
<link rel="stylesheet" href="{{URL::asset('frontend/css/owl.carousel.min.css')}}">
<link rel="stylesheet" href="{{URL::asset('frontend/css/themify-icons.css')}}">
<link rel="stylesheet" href="{{URL::asset('frontend/css/pe-icon-7-stroke.css')}}">
<link rel="stylesheet" href="{{URL::asset('frontend/css/icofont.css')}}">
<link rel="stylesheet" href="{{URL::asset('frontend/css/meanmenu.min.css')}}">
<link rel="stylesheet" href="{{URL::asset('frontend/css/bundle.css')}}">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css" integrity="sha512-HK5fgLBL+xu6dm/Ii3z4xhlSUyZgTT9tuc/hSrtw6uzJOvgRr2a9jyxxT1ely+B+xFAmJKVSTbpM/CuL7qxO8w==" crossorigin="anonymous" />
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
<link rel="stylesheet" href="{{URL::asset('frontend/css/style.css')}}">
<link rel="stylesheet" href="{{URL::asset('frontend/css/responsive.css')}}">
<link rel="stylesheet" href="{{URL::asset('frontend/css/mycss.css')}}">
