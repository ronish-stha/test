<div class="breadcrumb-area pt-205 breadcrumb-padding pb-210"
     style=" height: 200px; background-image: url(../../frontend/img/banner/breadcumb.jpg)">
    <div class="container-fluid">
        <div class="breadcrumb-content text-center">
            <h2> shop grid</h2>
            <ul>
                <li><a href="#">home</a></li>
                <li>shop grid</li>
            </ul>
        </div>
    </div>
</div>
