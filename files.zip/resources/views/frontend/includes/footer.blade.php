<footer class="footer-area" style="background: #e12c2c;">
    <div class="footer-top-area pt-70 pb-35 wrapper-padding-5">
        <div class="container-fluid">
            <div class="widget-wrapper">
                <div class="footer-widget mb-30">
                    <a href="#"><img src="{{ asset('frontend/img/logo/2.png') }}" alt=""></a>
                    <div class="footer-about-2">
                        <p>There are many variations of passages of Lorem Ipsum <br>the majority have suffered alteration in some form, by <br> injected humour</p>
                    </div>
                </div>
                <div class="footer-widget mb-30">
                    <h3 class="footer-widget-title-5" style="color: white">Contact Info</h3>
                    <div class="footer-info-wrapper-3">
                        <div class="footer-address-furniture">
                            <div class="footer-info-icon3">
                                <span>Address: </span>
                            </div>
                            <div class="footer-info-content3">
                                <p>Hattisar <br>Kathmandu, Nepal</p>
                            </div>
                        </div>
                        <div class="footer-address-furniture">
                            <div class="footer-info-icon3">
                                <span>Phone: </span>
                            </div>
                            <div class="footer-info-content3">
                                <p>+977 (33) 515609735 <br>+977 (66) 223352333</p>
                            </div>
                        </div>
                        <div class="footer-address-furniture">
                            <div class="footer-info-icon3">
                                <span>E-mail: </span>
                            </div>
                            <div class="footer-info-content3">
                                <p><a href="#"> email@domain.com</a> <br><a href="#"> domain@mail.info</a></p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="footer-widget mb-30">
                    <h3 class="footer-widget-title-5" style="color: white">Social Media</h3>
                    <div class="footer-newsletter-2">
                        <p style="color: #bfbfbf">Follow us on our Social Media Page</p>
                        <div id="mc_embed_signup" class="subscribe-form-5">

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-bottom ptb-20" style="background-color: black">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <div class="copyright-furniture">
                        <p>Copyright © <a href="https://hastech.company/">liquor shop</a> 2020 . All Right Reserved.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
