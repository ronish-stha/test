<div class="modal  fade" id="LocationModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-md" role="document">
        <div class="modal-content ptb-30" style="padding-left: 30px; padding-right:30px">
                <div><span><h5>Where you at?</div>
                <div><span><p>Enter your delivery address so we can show pricing and Availability for product in your area.</p></span></div>
                <div><span><input type="text" placeholder="Enter your location here"></span></div>
                <div class="pt-15"><span><a href="" type="btn btn-transparent" style="color: #e12c2c;">Check Availability</a></span></div>
        </div>
    </div>
</div>
